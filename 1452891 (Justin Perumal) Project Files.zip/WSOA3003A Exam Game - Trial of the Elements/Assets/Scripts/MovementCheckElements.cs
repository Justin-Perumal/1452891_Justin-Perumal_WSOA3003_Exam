﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovementCheckElements : MonoBehaviour
{

    public GridMovement Move;
    public MovementCheck MC;
    public GameObject Player;
    public GameObject PlayerLeft, PlayerRight, PlayerUp, PlayerDown;
    // Start is called before the first frame update
    void Awake()
    {
        Player = GameObject.FindGameObjectWithTag("Player");
        PlayerLeft = GameObject.FindGameObjectWithTag("LeftBound");
        PlayerRight = GameObject.FindGameObjectWithTag("RightBound");
        PlayerUp = GameObject.FindGameObjectWithTag("TopBound");
        PlayerDown = GameObject.FindGameObjectWithTag("BottomBound");
    }

    void Start()
    {
        Move = Player.GetComponent<GridMovement>();
        if(gameObject.tag == "LeftElement")
        {
            MC = PlayerLeft.GetComponent<MovementCheck>();
        }
        if(gameObject.tag == "RightElement")
        {
            MC = PlayerRight.GetComponent<MovementCheck>();
        }
        if(gameObject.tag == "TopElement")
        {
            MC = PlayerUp.GetComponent<MovementCheck>();
        }
        if(gameObject.tag == "BottomElement")
        {
            MC = PlayerDown.GetComponent<MovementCheck>();
        }
    }
    // Update is called once per frame
    void Update()
    {
        gameObject.transform.eulerAngles = new Vector3(0,0,0);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(MC.ElementLeft)
        {
            if(gameObject.tag == "LeftElement" && (collision.tag == "Wall" || collision.tag == "Door"))
            {
                Move.CanMoveLeft = false;
            }
        }
        else 
        {
            Move.CanMoveLeft = true;
        }

        if(MC.ElementRight)
        {
            if(gameObject.tag == "RightElement" && (collision.tag == "Wall" || collision.tag == "Door"))
            {
                Move.CanMoveRight = false;
            }
        }
        else
        {
            Move.CanMoveRight = true;
        }

        if(MC.ElementTop)
        {
            if(gameObject.tag == "TopElement" && (collision.tag == "Wall" || collision.tag == "Door"))
            {
                Move.CanMoveUp = false;
            }
        }
        else
        {
            Move.CanMoveUp = true;
        }

        if(MC.ElementBottom)
        {
            if(gameObject.tag == "BottomElement" && (collision.tag == "Wall" || collision.tag == "Door"))
            {
                Move.CanMoveDown = false;
            }
        }
        else
        {
            Move.CanMoveDown = true;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if(gameObject.tag == "LeftElement" && (collision.tag == "Wall" || collision.tag == "Door"))
        {
            Move.CanMoveLeft = true;
        }
    }
}
