﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProjectileMovement : MonoBehaviour
{
    public EnemyProjectile EP;
    // Start is called before the first frame update
    void Start()
    {
        EP = gameObject.transform.parent.gameObject.GetComponent<EnemyProjectile>();
    }

    // Update is called once per frame
    void Update()
    {
        if(EP.ProjectileDirection == "Up")
        {
            transform.Translate(Vector3.up * 0.05f, Camera.main.transform);
        }
        if(EP.ProjectileDirection == "Left")
        {
            transform.Translate(Vector3.left * 0.05f, Camera.main.transform);
        }
        if(EP.ProjectileDirection == "Down")
        {
            transform.Translate(Vector3.down * 0.05f, Camera.main.transform);
        }
        if(EP.ProjectileDirection == "Right")
        {
            transform.Translate(Vector3.right * 0.05f, Camera.main.transform);
        }
    }
    
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.tag == "Bounds" || collision.tag == "Earth")
        {
            Destroy(gameObject);
        }
    }
}
