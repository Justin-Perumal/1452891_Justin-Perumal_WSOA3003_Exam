﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class UserInterface : MonoBehaviour
{
    public GridMovement GM;
    public GameObject MoveText;
    public GameObject TimerText;
    // Start is called before the first frame update
    void Start()
    {
        GM = GameObject.FindGameObjectWithTag("Player").GetComponent<GridMovement>();
    }

    // Update is called once per frame
    void Update()
    {
        TimerText.GetComponent<TextMeshProUGUI>().text = "Level Time: " + GM.LevelTimer.ToString("F2");
        MoveText.GetComponent<TextMeshProUGUI>().text = "Moves made: " + GM.MoveAmount.ToString();
    }
}
