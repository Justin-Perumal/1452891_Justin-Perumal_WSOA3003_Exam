﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneTransition : MonoBehaviour
{
    public GridMovement GM;
    // Start is called before the first frame update
    void Start()
    {
        GM = GameObject.FindGameObjectWithTag("Player").GetComponent<GridMovement>();
        if(GM == null)
        {
            return;
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void GoToNextLevel()
    {
        if(GM.CurrentLevel == "TestScene")
        {
            SceneManager.LoadScene("Level 1");
            Time.timeScale = 1f;
        }

        if(GM.CurrentLevel == "Level 1")
        {
            SceneManager.LoadScene("Level 2");
            Time.timeScale = 1f;
        }
    }

    public void GoToMenu()
    {
        SceneManager.LoadScene("MainMenu");
        Time.timeScale = 1f;
    }

    public void StartGame()
    {
        SceneManager.LoadScene("Level 1");
        Time.timeScale = 1f;
    }

    public void StartTutorial()
    {
        SceneManager.LoadScene("Tutorial");
        Time.timeScale = 1f;
    }

    public void EndGame()
    {
        Application.Quit();
    }
}
