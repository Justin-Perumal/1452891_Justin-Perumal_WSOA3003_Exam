﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class GridMovement : MonoBehaviour
{
    public IceMovement IM;
    Scene CurrentScene;
    public string CurrentLevel;
    public GameObject TutorialDeathText;
    public Transform IcePosStart;
    public Transform IcePosEnd;
    private bool Moving;
    private Vector3 OriginalPos;
    private Vector3 TargetPos;
    private float MoveTimer = 0.15f;
    public GameObject Player;
    
    public bool CanMoveLeft;
    public bool CanMoveRight;
    public bool CanMoveUp;
    public bool CanMoveDown;
    public bool IcePath;
    public int MoveAmount;
    public float LevelTimer;

    void Start()
    {
        CurrentScene = SceneManager.GetActiveScene();
        CurrentLevel = CurrentScene.name;
        MoveAmount = 0;
        LevelTimer = 0;
        CanMoveDown = true;
        CanMoveLeft = true;
        CanMoveUp = true;
        CanMoveRight = true;
        IcePath = false;

        if(TutorialDeathText == null)
        {
            return;
        }
    }

    void Update()
    {
        LevelTimer += Time.deltaTime;
        if(!IcePath)
        {
            if(Input.GetKeyDown(KeyCode.W) && !Moving && CanMoveUp)
            {
                StartCoroutine(MovePlayer(Vector3.up));
                Player.transform.eulerAngles = new Vector3(0,0,0);
                MoveAmount++;
            }
            if(Input.GetKeyDown(KeyCode.A) && !Moving && CanMoveLeft)
            {
                StartCoroutine(MovePlayer(Vector3.left));
                Player.transform.eulerAngles = new Vector3(0,0,90f);
                MoveAmount++;
            }
            if(Input.GetKeyDown(KeyCode.S) && !Moving && CanMoveDown)
            {
                StartCoroutine(MovePlayer(Vector3.down));
                Player.transform.eulerAngles = new Vector3(0,0,180f);
                MoveAmount++;
            }
            if(Input.GetKeyDown(KeyCode.D) && !Moving && CanMoveRight)
            {
                StartCoroutine(MovePlayer(Vector3.right));
                Player.transform.eulerAngles = new Vector3(0,0,-90f);
                MoveAmount++;
            }
        }
        else MoveOnIce();

        if(Input.GetKeyDown(KeyCode.R))
        {
            SceneManager.LoadScene(CurrentLevel);
        }

        if(Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }
    }

    public void MoveOnIce()
    {
        transform.position = Vector2.MoveTowards(transform.position,IcePosEnd.position, 5f*Time.deltaTime);

        if(Vector2.Distance(transform.position, IcePosEnd.position) < 0.05f)
        {
            IcePath = false;
        }
    }
    private IEnumerator MovePlayer(Vector3 direction)
   {
       Moving = true;

       float TimeElapsed = 0;
       OriginalPos = transform.position;
       TargetPos = OriginalPos + direction;

       while(TimeElapsed < MoveTimer)
       {
           transform.position = Vector3.Lerp(OriginalPos, TargetPos, (TimeElapsed/MoveTimer));
           TimeElapsed += Time.deltaTime;
           yield return null;
       }

       transform.position = TargetPos;
       Moving = false;
   }

   public void OnTriggerEnter2D(Collider2D collision)
   {
       if(gameObject.tag == "Player" && (collision.tag == "Lava" || collision.tag == "Enemy" || collision.tag == "PitFall" || collision.tag == "Projectile"))
       {
           if(CurrentLevel == "Tutorial")
           {
               TargetPos = new Vector3(0f,26f,0f);
               TutorialDeathText.SetActive(true);
           }
           else gameObject.SetActive(false);
           SceneManager.LoadScene(CurrentLevel);
       }

       if(gameObject.tag == "Player" && collision.tag == "Ice" && !IcePath)
       {
           IM = collision.gameObject.GetComponent<IceMovement>();
           if(collision.gameObject.name == "IcePos1")
           {
               IcePosStart = IM.IcePositions[0];
               IcePosEnd = IM.IcePositions[1];
               IcePath = true;
           }
           if(collision.gameObject.name == "IcePos2")
           {
               IcePosStart = IM.IcePositions[1];
               IcePosEnd = IM.IcePositions[0];
               IcePath = true;
           }
           
       }

       if(gameObject.tag == "Player" && collision.tag == "EndPoint")
       {
            if(CurrentLevel == "Tutorial")
            {
                SceneManager.LoadScene("Level 1");
            }
            else
            {
                Debug.Log("Go to next level");
                Time.timeScale = 0f;
            }
       }
   }
}
