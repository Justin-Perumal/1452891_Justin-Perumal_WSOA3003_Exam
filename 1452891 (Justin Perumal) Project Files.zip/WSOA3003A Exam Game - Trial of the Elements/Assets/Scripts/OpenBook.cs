﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class OpenBook : MonoBehaviour
{
    public bool CanOpenBook;
    public GameObject BookPanel;
    public GameObject OpenBookText;
    public GameObject TutorialEndPoint;
    public GridMovement GM;
    // Start is called before the first frame update
    void Start()
    {
        GM = GameObject.FindGameObjectWithTag("Player").GetComponent<GridMovement>();
        CanOpenBook = false;
        if(TutorialEndPoint == null)
        {
            return;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if(CanOpenBook)
        {
            if(Input.GetKeyDown(KeyCode.E))
            {
                BookPanel.SetActive(true);
                if(GM.CurrentLevel == "Tutorial")
                {
                    TutorialEndPoint.SetActive(true);
                }
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.tag == "Player")
        {
            CanOpenBook = true;
            OpenBookText.SetActive(true);
        }
        Debug.Log("Can open book");
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if(collision.tag == "Player")
        {
            CanOpenBook = false;
            OpenBookText.SetActive(false);
        }
        Debug.Log("Can open book");
    }
}
