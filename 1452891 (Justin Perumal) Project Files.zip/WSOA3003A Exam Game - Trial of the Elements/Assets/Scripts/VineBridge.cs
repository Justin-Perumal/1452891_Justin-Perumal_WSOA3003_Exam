﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VineBridge : MonoBehaviour
{
    public GameObject[] VineBridgeObjects;
    public GameObject[] PitFallsCrossed;
    private int VineLength;
    // Start is called before the first frame update
    void Start()
    {
        VineLength = VineBridgeObjects.Length;
    }

    // Update is called once per frame
    void Update()
    {
        if(PitFallsCrossed == null)
        {
            return;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(gameObject.tag == "Flower" && collision.tag == "Mud")
        {
            for(int i = 0; i < VineLength ; i++)
            {
                VineBridgeObjects[i].SetActive(true);
                PitFallsCrossed[i].SetActive(false);
            }
            gameObject.SetActive(false);
            collision.gameObject.SetActive(false);
        }
    }
}
