﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovementCheck : MonoBehaviour
{
    public GridMovement Move;
    public GameObject Player;
    public bool ElementRight;
    public bool ElementLeft;
    public bool ElementTop;
    public bool ElementBottom;
    public BoxCollider2D ElementBoxTop;
    public BoxCollider2D  ElementBoxBottom;
    public BoxCollider2D ElementBoxLeft;
    public BoxCollider2D ElementBoxRight;
    // Start is called before the first frame update
    void Awake()
    {
        Player = GameObject.FindGameObjectWithTag("Player");
    }

    void Start()
    {
        Move = Player.GetComponent<GridMovement>();
        ElementBottom = false;
        ElementTop = false;
        ElementLeft = false;
        ElementRight = false;
    }
    // Update is called once per frame
    void Update()
    {
        
        gameObject.transform.eulerAngles = new Vector3(0,0,0);
        if(ElementBoxBottom == null || ElementBoxLeft == null || ElementBoxRight == null || ElementBoxRight == null)
        {
            return;
        }

        if(ElementLeft == false)
        {
            ElementBoxLeft.enabled = false;
        }
        else if(ElementLeft == true)
        {
            ElementBoxLeft.enabled = true;
        }

        if(ElementRight == false)
        {
            ElementBoxRight.enabled = false;
        }
        else if(ElementRight == true)
        {
            ElementBoxRight.enabled = true;
        }

        if(ElementTop == false)
        {
            ElementBoxTop.enabled = false;
        }
        else if(ElementTop == true)
        {
            ElementBoxTop.enabled = true;
        }

        if(ElementBottom == false)
        {
            ElementBoxBottom.enabled = false;
        }
        else if(ElementBottom == true)
        {
            ElementBoxBottom.enabled = true;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if((collision.tag == "Wall" || collision.tag == "Door" || collision.tag == "Lecturn") && gameObject.tag == "LeftBound")
        {
            Move.CanMoveLeft = false;
        }
        if((collision.tag == "Wall" || collision.tag == "Door" || collision.tag == "Lecturn") && gameObject.tag == "RightBound")
        {
            Move.CanMoveRight = false;
        }
        if((collision.tag == "Wall" || collision.tag == "Door" || collision.tag == "Lecturn") && gameObject.tag == "TopBound")
        {
            Move.CanMoveUp = false;
        }
        if((collision.tag == "Wall" || collision.tag == "Door" || collision.tag == "Lecturn") && gameObject.tag == "BottomBound")
        {
            Move.CanMoveDown = false;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if((collision.tag == "Wall" || collision.tag == "Door" || collision.tag == "Lecturn") && gameObject.tag == "LeftBound")
        {
            Move.CanMoveLeft = true;
        }
        if((collision.tag == "Wall" || collision.tag == "Door" || collision.tag == "Lecturn") && gameObject.tag == "RightBound")
        {
            Move.CanMoveRight = true;
        }
        if((collision.tag == "Wall" || collision.tag == "Door" || collision.tag == "Lecturn") && gameObject.tag == "TopBound")
        {
            Move.CanMoveUp = true;
        }
        if((collision.tag == "Wall" || collision.tag == "Door" || collision.tag == "Lecturn") && gameObject.tag == "BottomBound")
        {
            Move.CanMoveDown = true;
        }

        if(gameObject.tag == "LeftBound" && (collision.tag == "Fire" || collision.tag == "Water" || collision.tag == "Earth" || collision.tag == "Mud" || collision.tag == "Steam"))
        {
            Move.CanMoveLeft = true;
            ElementLeft = false;
            ElementBoxLeft.enabled = false;
        } 

        if(gameObject.tag == "RightBound" && (collision.tag == "Fire" || collision.tag == "Water" || collision.tag == "Earth" || collision.tag == "Mud" || collision.tag == "Steam"))
        {
            Move.CanMoveRight = true;
            ElementRight = false;
            ElementBoxRight.enabled = false;
        }

        if(gameObject.tag == "TopBound" && (collision.tag == "Fire" || collision.tag == "Water" || collision.tag == "Earth" || collision.tag == "Mud" || collision.tag == "Steam"))
        {
            Move.CanMoveUp = true;
            ElementTop = false;
            ElementBoxTop.enabled = false;
        }

        if(gameObject.tag == "BottomBound" && (collision.tag == "Fire" || collision.tag == "Water" || collision.tag == "Earth" || collision.tag == "Mud" || collision.tag == "Steam"))
        {
            Move.CanMoveDown = true;
            ElementBottom = false;
            ElementBoxBottom.enabled = false;
        }
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        if(gameObject.tag == "LeftBound" && (collision.tag == "Wall" || collision.tag == "Door" || collision.tag == "Lecturn"))
        {
            Move.CanMoveLeft = false;
        }
        if(gameObject.tag == "RightBound" && (collision.tag == "Wall" || collision.tag == "Door" || collision.tag == "Lecturn"))
        {
            Move.CanMoveRight = false;
        }
        if(gameObject.tag == "TopBound" && (collision.tag == "Wall" || collision.tag == "Door" || collision.tag == "Lecturn"))
        {
            Move.CanMoveUp = false;
        }
        if(gameObject.tag == "BottomBound" && (collision.tag == "Wall" || collision.tag == "Door" || collision.tag == "Lecturn"))
        {
            Move.CanMoveDown = false;
        }

        if(gameObject.tag == "LeftBound" && (collision.tag == "Fire" || collision.tag == "Water" || collision.tag == "Earth" || collision.tag == "Mud" || collision.tag == "Steam"))
        {
            ElementBoxLeft.enabled = true;
            ElementLeft = true;
        }

        if(gameObject.tag == "RightBound" && (collision.tag == "Fire" || collision.tag == "Water" || collision.tag == "Earth" || collision.tag == "Mud" || collision.tag == "Steam"))
        {
            ElementRight = true;
            ElementBoxRight.enabled = true;
        }

        if(gameObject.tag == "TopBound" && (collision.tag == "Fire" || collision.tag == "Water" || collision.tag == "Earth" || collision.tag == "Mud" || collision.tag == "Steam"))
        {
            ElementTop = true;
            ElementBoxTop.enabled = true;
        }

        if(gameObject.tag == "BottomBound" && (collision.tag == "Fire" || collision.tag == "Water" || collision.tag == "Earth" || collision.tag == "Mud" || collision.tag == "Steam"))
        {
            ElementBoxBottom.enabled = true;
            ElementBottom = true;
        }
    }
}
