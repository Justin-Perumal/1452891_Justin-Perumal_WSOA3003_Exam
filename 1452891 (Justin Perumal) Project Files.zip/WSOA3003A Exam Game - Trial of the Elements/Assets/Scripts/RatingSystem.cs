﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class RatingSystem : MonoBehaviour
{
    public GridMovement GM;
    public GameObject EndLevelPanel;
    public GameObject EndTimeText;
    public GameObject EndMoveText;
    public GameObject[] Rating;
    // Start is called before the first frame update
    void Start()
    {
        GM = GameObject.FindGameObjectWithTag("Player").GetComponent<GridMovement>();
    }

    // Update is called once per frame
    void Update()
    {
        EndTimeText.GetComponent<TextMeshProUGUI>().text = "Your time to complete the level: " + GM.LevelTimer.ToString("F2");
        EndMoveText.GetComponent<TextMeshProUGUI>().text = "You took " + GM.MoveAmount.ToString() + " moves to complete the level!";

        if(GM.LevelTimer <= 60f)
        {
            Rating[0].SetActive(true);
            Rating[1].SetActive(true);
            Rating[2].SetActive(true);
        }
        if(GM.LevelTimer > 60f && GM.LevelTimer <= 120f)
        {
            Rating[0].SetActive(true);
            Rating[1].SetActive(true);
            Rating[2].SetActive(false);
        }
        if(GM.LevelTimer > 120)
        {
            Rating[0].SetActive(true);
            Rating[1].SetActive(false);
            Rating[2].SetActive(false);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.tag == "Player")
        {
            EndLevelPanel.SetActive(true);
        }
    }
}
