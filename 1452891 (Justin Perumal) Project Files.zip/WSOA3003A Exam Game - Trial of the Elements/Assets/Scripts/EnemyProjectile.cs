﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyProjectile : MonoBehaviour
{
    public GameObject Projectile;
    public float ProjectileDelay;
    public float ProjectileTimer;
    public string ProjectileDirection;

    // Start is called before the first frame update
    void Start()
    {
        ProjectileTimer = 0f;
        ProjectileDelay = 2.5f;
    }

    // Update is called once per frame
    void Update()
    {
        if(ProjectileTimer <= ProjectileDelay)
        {
            ProjectileTimer += Time.deltaTime;
            Debug.Log("Time to Shoot");
        }
        else if(ProjectileTimer > ProjectileDelay)
        {
            GameObject NewProjectile = Instantiate(Projectile,gameObject.transform.position, Quaternion.identity);
            NewProjectile.transform.parent = gameObject.transform;
            ProjectileTimer =0;
        }
    }
}
