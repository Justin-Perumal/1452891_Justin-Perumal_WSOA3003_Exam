﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ElementCombination : MonoBehaviour
{
    public Vector3 NewElementPos;
    public GameObject Steam;
    public GameObject Mud;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void OnTriggerEnter2D(Collider2D collision)
    {
        if(gameObject.tag =="Water" && collision.tag =="Fire")
        {
            NewElementPos = collision.gameObject.transform.position;
            Instantiate(Steam, NewElementPos, Quaternion.identity);
            collision.gameObject.SetActive(false);
            gameObject.SetActive(false);
            Debug.Log("Make steam");
        }

        if(gameObject.tag =="Water" && collision.tag =="Earth")
        {
            NewElementPos = collision.gameObject.transform.position;
            Instantiate(Mud, NewElementPos, Quaternion.identity);
            collision.gameObject.SetActive(false);
            gameObject.SetActive(false);
            Debug.Log("Make mud");
        }

        if(gameObject.tag =="Fire" && collision.tag == "Door")
        {
            collision.gameObject.SetActive(false);
            gameObject.SetActive(false);
        }

        if(gameObject.tag == "Earth" && collision.tag == "PitFall")
        {
            collision.gameObject.SetActive(false);
            gameObject.SetActive(false);
        }
    }

}
